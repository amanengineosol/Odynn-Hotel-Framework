
        chrome.proxy.settings.set({value: {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "us.smartproxy.com",
                port: parseInt(10052)
              },
              bypassList: ["localhost"]
            }
        }, scope: "regular"}, function() {});

        chrome.webRequest.onAuthRequired.addListener(
            function(details, callback) {
                callback({authCredentials: {username: "engineo3", password: "7s4Nd2+nnzs7OdeKsU"}});
            },
            {urls: ["<all_urls>"]},
            ['blocking']
        );
        