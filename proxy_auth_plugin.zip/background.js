
        chrome.proxy.settings.set({value: {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "169.197.83.74",
                port: parseInt(6153)
              },
              bypassList: ["localhost"]
            }
        }, scope: "regular"}, function() {});

        chrome.webRequest.onAuthRequired.addListener(
            function(details, callback) {
                callback({authCredentials: {username: "p7gbh", password: "qonfo4j6"}});
            },
            {urls: ["<all_urls>"]},
            ['blocking']
        );
        